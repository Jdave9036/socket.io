
## Table of Contents

#### Getting started

  - [Write a chat application](http://socket.io/get-started/chat/)

#### API Reference

  - [Server API](API.md)
  - [Client API](https://github.com/socketio/socket.io-client/blob/master/docs/API.md)

#### Advanced topics

  - [Emit cheatsheet](emit.md)
